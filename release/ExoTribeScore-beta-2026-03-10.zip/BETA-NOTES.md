# ExoTribeScore Beta Notes

## Beta Status

This build is suitable for a controlled beta with a small number of server operators.

This build is not ready for a wide or public beta yet.

## Known Risks

- Reload can accept a broken MySQL config and clear the in-memory score cache.
- Score, score event, and tribe member writes are not persisted as one atomic transaction.
- `/leaderboard` can trigger a full rewrite of the `tribe_scores` table when tribe names change.
- ODBC connection-string values are not escaped, so some valid passwords may fail.

See [AUDIT.md](E:\My projects\Ark Plugins\ExoTribeScore\docs\AUDIT.md) for the full audit.

## Requirements

- ARK Server API installed on the target server.
- MySQL server reachable from the ARK host.
- A compatible MySQL ODBC driver installed on the ARK host.
- `config.json` updated with real MySQL connection details before use.

## Package Contents

- `ArkApi/Plugins/ExoTribeScore/ExoTribeScore.dll`
- `ArkApi/Plugins/ExoTribeScore/config.json`
- `ArkApi/Plugins/ExoTribeScore/PluginInfo.json`
- `README.md`
- `docs/`

## Install

1. Copy the contents of `ArkApi/Plugins/ExoTribeScore` into the target server's `ArkApi/Plugins/ExoTribeScore`.
2. Edit `config.json` with the target MySQL details.
3. Confirm the ODBC driver name in `config.json` matches the driver installed on the target machine.
4. Start the server and check the plugin logs.
