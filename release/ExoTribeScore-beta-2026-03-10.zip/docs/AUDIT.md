# Code Audit

Audit date: 2026-03-10

Scope:

- [Plugin.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\Plugin.cpp)
- [Config.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\Config.cpp)
- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp)
- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp)

## Findings

### 1. Reload can silently activate a broken database config and clear the live score cache

Severity: High

Files:

- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp#L277)
- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp#L303)

Details:

- `ReloadConfigInternal()` swaps `active_config_` before proving the new MySQL settings are usable.
- It then calls `LoadScores()`.
- If the database connection fails, `LoadScores()` clears `scores_`.
- Reload still returns a success message because database load failure does not fail the reload path.

Impact:

- a typo in the MySQL config can make the plugin appear successfully reloaded while effectively disabling the leaderboard and wiping the in-memory cache
- subsequent score writes continue to fail against the new config

### 2. A single score event is persisted as multiple independent database writes

Severity: High

Files:

- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp#L196)
- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp#L378)
- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp#L509)
- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp#L543)

Details:

- score mutation, event insertion, and tribe member sync are split across separate database operations
- if `tribe_scores` save succeeds but `score_events` or `tribe_members` writes fail, the database is left in a partial state

Impact:

- leaderboard state can diverge from event history
- tribe roster snapshots can lag behind the score that produced them
- recovery requires manual reconciliation

### 3. Leaderboard reads can trigger a full table rewrite of `tribe_scores`

Severity: Medium

Files:

- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp#L518)
- [TribeScoreService.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\TribeScoreService.cpp#L749)
- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp#L398)

Details:

- `/leaderboard` resolves live tribe names
- if a tribe name changed, `RefreshStoredTribeName()` persists the entire cached score snapshot
- `ScoreStore::Save()` deletes every row from `tribe_scores` and reinserts the whole dataset

Impact:

- a read-only operation performs a write-heavy full-table replacement
- this increases lock time and raises the risk of clobbering newer data if the plugin is ever used against a shared database

### 4. ODBC connection-string values are not escaped

Severity: Medium

Files:

- [ScoreStore.cpp](E:\My projects\Ark Plugins\ExoTribeScore\src\ScoreStore.cpp#L124)

Details:

- the connection string is assembled by concatenating raw config values
- ODBC connection strings treat characters like `;`, `{`, and `}` specially
- a valid password or driver string containing those characters can break login

Impact:

- strong passwords or unusual driver names can fail unexpectedly
- failures present as connection errors even though the credentials are otherwise valid

## Recommended Fix Order

1. Make reload fail closed if the new database config cannot connect and load scores.
2. Replace the multi-step persistence flow with one transactional score-event write path.
3. Stop rewriting the entire `tribe_scores` table for name refreshes.
4. Escape or quote ODBC connection-string values correctly.
